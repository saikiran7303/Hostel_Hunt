<div className="dropdown">
  <Link className="btn btn-secondary dropdown-toggle" to="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    Dropdown link
  </Link>

  <ul className="dropdown-menu">
    <li><Link className="dropdown-item" to="#">Action</Link></li>
    <li><Link className="dropdown-item" to="#">Another action</Link></li>
    <li><Link className="dropdown-item" to="#">Something else here</Link></li>
  </ul>
</div>